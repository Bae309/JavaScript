const str = "Hello, world!"; // Hello World 문자열 변수 선언
function getLength() { // getLength 함수 생성
    let i = str.length; // 문자열의 길이 반환
    return i;
}

console.log(getLength(str)); // 콘솔에 결과 나타내기