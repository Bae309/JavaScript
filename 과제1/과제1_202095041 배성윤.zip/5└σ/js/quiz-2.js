function gcd(a,b) {
    while(b !== 0) {
        let temp = a % b;
        a = b;
        b = temp;
    }
    return a;
}


const number1 = document.querySelector("#number1");
const number2 = document.querySelector("#number2");
const bttn = document.querySelector("#calc");
const result = document.querySelector("#result");

bttn.addEventListener('click', function() {
    const num1 = parseInt(number1.value);
    const num2 = parseInt(number2.value);

    const gCD = gcd(num1, num2);
    result.textContent = `${gCD}`
})

